package com.example.tourguide;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.tourguide.adapter.RecentsAdapter;
import com.example.tourguide.adapter.TopPlacesAdapter;
import com.example.tourguide.model.RecentsData;
import com.example.tourguide.model.TopPlacesData;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recentRecycler, topPlacesRecycler;
    RecentsAdapter recentsAdapter;
    TopPlacesAdapter topPlacesAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        List<RecentsData> recentsDataList = new ArrayList<>();
        recentsDataList.add(new RecentsData("AM Lake","India","From ₹20,000",R.drawable.recentimage1));
        recentsDataList.add(new RecentsData("Nilgiri Hills","India","From ₹30,000",R.drawable.recentimage2));
        recentsDataList.add(new RecentsData("AM Lake","India","From ₹20,000",R.drawable.recentimage1));
        recentsDataList.add(new RecentsData("Nilgiri Hills","India","From ₹30,000",R.drawable.recentimage2));
        recentsDataList.add(new RecentsData("AM Lake","India","From ₹20,000",R.drawable.recentimage1));
        recentsDataList.add(new RecentsData("Nilgiri Hills","India","From ₹30,000",R.drawable.recentimage2));

        setRecentRecycler(recentsDataList);

        List<TopPlacesData> topPlacesDataList = new ArrayList<>();
        topPlacesDataList.add(new TopPlacesData("Kasimir Hills","India","₹20,000 - ₹50,000",R.drawable.topplaces));
        topPlacesDataList.add(new TopPlacesData("Nandhi Hills","India","₹20,000 - ₹50,000",R.drawable.topplaces));
        topPlacesDataList.add(new TopPlacesData("Dhwaraka","India","₹20,000 - ₹50,000",R.drawable.topplaces));
        topPlacesDataList.add(new TopPlacesData("Tea Tree Stations","India","₹20,000 - ₹50,000",R.drawable.topplaces));
        topPlacesDataList.add(new TopPlacesData("Blue Sea","India","₹20,000 - ₹50,000",R.drawable.topplaces));

        setTopPlacesRecycler(topPlacesDataList);
    }

    private  void setRecentRecycler(List<RecentsData> recentsDataList){

        recentRecycler = findViewById(R.id.recent_recycler);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        recentRecycler.setLayoutManager(layoutManager);
        recentsAdapter = new RecentsAdapter(this, recentsDataList);
        recentRecycler.setAdapter(recentsAdapter);

    }

    private  void setTopPlacesRecycler(List<TopPlacesData> topPlacesDataList){

        topPlacesRecycler = findViewById(R.id.top_places_recycler);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        topPlacesRecycler.setLayoutManager(layoutManager);
        topPlacesAdapter = new TopPlacesAdapter(this, topPlacesDataList);
        topPlacesRecycler.setAdapter(topPlacesAdapter);

    }
}